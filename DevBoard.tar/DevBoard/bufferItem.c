/*#include "bufferItem.h"

bufferItem::bufferItem(char *str, uint8_t pos)
{
	this->next = NULL;
	this->str = str;
	this->pos = pos;
}*/
