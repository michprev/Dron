#include "stringBuffer.h"

char* stringBufferAdd(stringBuffer *b)
{
	char *str = malloc(sizeof(char) * 50);

	bufferItem *tmp = malloc(sizeof(struct bufferItem));
	tmp->next = NULL;
	tmp->str = str;

	if (b->last != NULL) {
		b->last->next = tmp;
	}
	else {
		b->last = tmp;
		b->first = b->last;
	}

	b->count++;

	return str;
}

void stringBufferRemove(stringBuffer *b)
{
	bufferItem *tmp = b->first->next;

	free(b->first->str);
	free(b->first);
	b->first = tmp;

	b->count--;
}
